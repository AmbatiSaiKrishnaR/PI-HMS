import React, {FC} from 'react'
import {StaffDtails } from '../../../../_metronic/partials'

const Staff: FC = () => {
  return (
    <>
      <StaffDtails className='mb-5 mb-xl-8' />

    </>
  )
}

export {Staff}