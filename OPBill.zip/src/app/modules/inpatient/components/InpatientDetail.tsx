import React, {FC} from 'react'

import {InpatientDetails} from '../../../../_metronic/partials/inpatient/InpatientDetails'

const InpatientDetail: FC = () => {
  return (
    <>
      {/* <InPatientDetail >className='mb-5 mb-xl-8' /> */}
      <InpatientDetails />
    </>
  )
}

export {InpatientDetail}
